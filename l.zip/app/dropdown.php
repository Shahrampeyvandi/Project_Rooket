<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class dropdown extends Model
{
    protected $guarded=['id'];
}
