<footer>
   <div class="footer-top">
      <div class="container">
          <div class="row">
              <div class="col-md-3 col-sm-6 col-xs-12 segment-one">
                  <h3>عنوان</h3>
                  <p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت</p>
              </div>
              <div class="col-md-3 col-sm-6 col-xs-12 segment-two">
                  <h2>عنوان</h2>
                  <ul>
                      <li><a href="">خانه</a></li>
                      <li><a href="">درباره ما</a></li>
                      <li><a href="">محصولات</a></li>
                      <li><a href="">ارتباط با ما</a></li>
                      <li><a href="">خبر</a></li>
                  </ul>
              </div>
              <div class="col-md-3 col-sm-6 col-xs-12 segment-three" >
                  <h2>لطفا بخوانید</h2>
                  <p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت</p>
                  <a class="facebook" style="background: #0000cc" href=""><i class="fa fa-facebook"></i></a>
                  <a class="instagram"  href=""><i class="fa fa-instagram"></i></a>
                  <a class="twitter" style="background: #0000cc" href=""><i class="fa fa-twitter"></i></a>
                  <a class="telegram" style="background: #0000cc" href=""><i class="fa fa-telegram"></i></a>
              </div>
              <div class="col-md-3 col-sm-6 col-xs-12 segment-four" >
                    <h2>جست وجو</h2>
                  <input type="text" class="">
                  <input type="submit" value="ارسال" class="">

              </div>
      </div>
   </div>
       <p class="footer-bottom-text">
            هرگونه کبی برداری از این سایت غیر قانونی میباشد
       </p>
</footer>
